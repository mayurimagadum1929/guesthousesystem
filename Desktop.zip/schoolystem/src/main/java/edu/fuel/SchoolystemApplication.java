package edu.fuel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolystemApplication.class, args);
	}

}
