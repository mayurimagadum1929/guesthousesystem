package edu.fuel;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/school")

public class SchoolController {
	@Autowired
	SchoolRepository schoolRepository;
	@GetMapping
	public List<School> fetch()
	 {
	    List<School> l1=schoolRepository.findAll();	 
	    return l1;
	 }
	@PostMapping
	public School addSchool(@RequestBody School school)
	{
		 School s1= schoolRepository.save(school);
		 return s1;
	

}

		
}
