package edu.fuel;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_school")

public class School {
	@Id
	private int regno;
	private String name;
	private String city;
	private String state;
	private String country;
	private String email;
	private String phone;
	private String totalStudents;
	private String totalTeachers;
	private String princialname;
	private String grade;
	private String year;
	
	
	
   public School() {
	   super();
	   //TODO Auto-generated constructor stub
   }
	public int getRegno() {
		return regno;
	}
	public void setRegno(int regno) {
		this.regno = regno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getTotalStudents() {
		return totalStudents;
	}
	public void setTotalStudents(String totalStudents) {
		this.totalStudents = totalStudents;
	}
	public String getTotalTeachers() {
		return totalTeachers;
	}
	public void setTotalTeachers(String totalTeachers) {
		this.totalTeachers = totalTeachers;
	}
	public String getPrincialname() {
		return princialname;
	}
	public void setPrincialname(String princialname) {
		this.princialname = princialname;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	

}
