package com.edufuel;

public class singleDemo {

}
